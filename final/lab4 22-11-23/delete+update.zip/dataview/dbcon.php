<?php
	$db=mysqli_connect("localhost","root","","info_db");
	define("BASE", "http://localhost/dataview/");
?>