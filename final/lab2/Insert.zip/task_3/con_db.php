<?php
	$host = 'localhost';
	$dbName = 'cse_458';
	$userName = 'root';
	$pwd = '';
	/*Connection*/
$dbCon = mysqli_connect($host, $userName, $pwd, $dbName);
@define("BASE", "http://localhost:9090/cse_458/FINAL/task_3/");
?>